namespace ChoreMonitor.Features.Chores.Create
{
    public class Result
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}